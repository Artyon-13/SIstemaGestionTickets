package edu.unl.cc;
// Nodo de lista enlazada que almacena una accion y un enlace al siguiente nodo
public class NodoAccion {
    String accion;
    NodoAccion siguiente;

    public NodoAccion(String accion) {
        this.accion = accion;
    }


}

