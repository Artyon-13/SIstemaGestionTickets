package edu.unl.cc;

public enum EstadoTicket {
    En_Cola,
    En_Atencion,
    En_Proceso,
    Pendiente_DOCS,
    Completado
}
